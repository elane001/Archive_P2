#!/bin/bash

decimal="$1"

if [ "$#" -ne 1 ]; then
        echo "Need to input a number"
        exit 1
fi

if [[ "$decimal" -ge 100000 ]];then
        echo "input too big!"
        exit 1
fi

decimal_to_binary() {
    local num="$1"
    local result=""
    local remainder

    while [ "$num" -gt 0 ]; do
        remainder=$((num % 2))
        result="${remainder}${result}"
        num=$((num / 2))
    done

    echo "$result"
}

decimal_to_hexadecimal() {
    local num="$1"
    local result=""
    local remainder

    while [ "$num" -gt 0 ]; do
        remainder=$((num % 16))
        if [ "$remainder" -ge 10 ]; then
            # Convert decimal values 10-15 to hexadecimal A-F
            case $remainder in
                10) remainder="A" ;;
                11) remainder="B" ;;
                12) remainder="C" ;;
                13) remainder="D" ;;
                14) remainder="E" ;;
                15) remainder="F" ;;
            esac
        fi
        result="${remainder}${result}"
        num=$((num / 16))

    done

    echo "$result"
}

binary=$(decimal_to_binary "$decimal")
hexy=$(decimal_to_hexadecimal "$decimal")


echo "decimal $decimal is: $binary in binary"
echo "decimal $decimal is: $hexy in hexadecimal"


